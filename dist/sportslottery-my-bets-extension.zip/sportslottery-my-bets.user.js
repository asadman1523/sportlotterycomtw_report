(() => {
  "use strict";

  const SPORTSBOOK_HOST = "www-talo-ssb-pr.sportslottery.com.tw";
  const MEMBER_HOST = "member.sportslottery.com.tw";
  const CARD_ATTR = "data-slb-bet-card";
  const SUMMARY_CLASS = "slb-bet-summary";
  const COLLAPSED_CLASS = "slb-bet-collapsed";

  const TEXT = {
    win: "\u8d0f",
    lose: "\u8f38",
    pending: "\u672a\u6d3e\u5f69",
    voided: "\u9000\u56de",
    unknown: "-",
    expand: "\u5c55\u958b",
    collapse: "\u6536\u5408",
    bet: "\u6295\u6ce8",
    option: "\u6295\u6ce8\u9078\u9805",
  };

  if (![SPORTSBOOK_HOST, MEMBER_HOST].includes(location.hostname)) return;

  onReady(() => {
    ensureStyles();
    if (location.hostname === SPORTSBOOK_HOST) startDecorator();
  });

  function onReady(callback) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", callback, { once: true });
    } else {
      callback();
    }
  }

  function startDecorator() {
    decorateAll();

    let timer = 0;
    const observer = new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(decorateAll, 150);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

    let attempts = 0;
    const interval = setInterval(() => {
      decorateAll();
      attempts += 1;
      if (attempts >= 20) clearInterval(interval);
    }, 1000);
  }

  function decorateAll() {
    for (const card of findBetCards()) {
      decorateCard(card);
    }
  }

  function findBetCards() {
    const selector = [
      "[class*='BetHistory']",
      "[class*='betHistory']",
      "[class*='bet-history']",
      "[class*='BetSlip']",
      "[class*='betSlip']",
      "[class*='bet-slip']",
      "[class*='Ticket']",
      "[class*='ticket']",
      "[class*='Coupon']",
      "[class*='coupon']",
      "li",
      "article",
    ].join(",");

    const candidates = Array.from(document.querySelectorAll(selector))
      .filter((element) => !element.closest(`.${SUMMARY_CLASS}`))
      .filter((element) => !element.hasAttribute(CARD_ATTR))
      .filter(isLikelyBetCard)
      .map(selectSmallestUsefulCard)
      .filter(Boolean);

    const unique = [];
    for (const candidate of candidates) {
      if (candidate.hasAttribute(CARD_ATTR)) continue;
      if (unique.includes(candidate)) continue;
      if (unique.some((item) => item.contains(candidate))) {
        const parentIndex = unique.findIndex((item) => item.contains(candidate));
        if (parentIndex >= 0 && isBetterCard(candidate, unique[parentIndex])) {
          unique[parentIndex] = candidate;
        }
        continue;
      }
      if (unique.some((item) => candidate.contains(item))) continue;
      unique.push(candidate);
    }

    return unique.slice(0, 80);
  }

  function isLikelyBetCard(element) {
    if (!isVisible(element)) return false;
    const text = normalizeText(element.innerText || element.textContent || "");
    if (text.length < 40 || text.length > 4000) return false;
    if (element.querySelectorAll(`.${SUMMARY_CLASS}`).length) return false;

    const hasDate = /20\d{2}[./-]\d{1,2}[./-]\d{1,2}|\d{1,2}[./-]\d{1,2}[./-]20\d{2}|\d{1,2}:\d{2}/.test(text);
    const betWords = [
      "\u6295\u6ce8",
      "\u6d3e\u5f69",
      "\u8f38",
      "\u8d0f",
      "\u8ce0\u7387",
      "\u73a9\u6cd5",
      "\u9078\u9805",
      "\u4e32\u95dc",
      "\u55ae\u865f",
      "Won",
      "Lost",
      "Opened",
      "Settled",
      "Stake",
      "Odds",
    ];
    const score = betWords.reduce((total, word) => total + (text.includes(word) ? 1 : 0), 0);
    return hasDate && score >= 2;
  }

  function selectSmallestUsefulCard(element) {
    let card = element;
    for (let current = element; current && current !== document.body; current = current.parentElement) {
      const text = normalizeText(current.innerText || current.textContent || "");
      if (text.length > 4000) break;
      if (isLikelyBetCard(current)) card = current;
      const siblingBetCount = Array.from(current.parentElement?.children || []).filter(isLikelyBetCard).length;
      if (siblingBetCount > 1) return current;
    }
    return card;
  }

  function isBetterCard(next, previous) {
    const nextText = normalizeText(next.innerText || next.textContent || "");
    const previousText = normalizeText(previous.innerText || previous.textContent || "");
    return nextText.length < previousText.length;
  }

  function decorateCard(card) {
    const summaryData = parseSummary(card);
    if (!summaryData) return;

    const summary = document.createElement("button");
    summary.type = "button";
    summary.className = SUMMARY_CLASS;
    summary.innerHTML = `
      <span class="slb-result slb-result-${summaryData.resultKind}">${escapeHtml(summaryData.result)}</span>
      <span class="slb-summary-text">${escapeHtml(summaryData.date)} - ${escapeHtml(summaryData.play)} -&gt; ${escapeHtml(summaryData.option)}</span>
      <span class="slb-summary-toggle">${TEXT.expand}</span>
    `;

    summary.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      card.classList.toggle(COLLAPSED_CLASS);
      const toggle = summary.querySelector(".slb-summary-toggle");
      if (toggle) toggle.textContent = card.classList.contains(COLLAPSED_CLASS) ? TEXT.expand : TEXT.collapse;
    });

    card.setAttribute(CARD_ATTR, "true");
    card.classList.add("slb-bet-card", COLLAPSED_CLASS);
    card.insertBefore(summary, card.firstChild);
  }

  function parseSummary(card) {
    const text = normalizeText(card.innerText || card.textContent || "");
    if (!text) return null;

    const result = parseResult(text);
    const date = parseDate(text);
    const play = parseField(text, [
      "\u73a9\u6cd5",
      "\u6295\u6ce8\u985e\u578b",
      "\u6295\u6ce8\u7a2e\u985e",
      "Market",
      "Bet Type",
    ]) || parsePlayFallback(text);
    const option = parseField(text, [
      "\u6295\u6ce8\u9078\u9805",
      "\u9078\u9805",
      "\u6295\u6ce8\u5167\u5bb9",
      "\u9078\u64c7",
      "Selection",
      "Pick",
    ]) || parseOptionFallback(text);

    return {
      result: result.label,
      resultKind: result.kind,
      date: date || TEXT.unknown,
      play: play || TEXT.bet,
      option: option || TEXT.option,
    };
  }

  function parseResult(text) {
    if (/Opened|Pending|\u672a\u6d3e\u5f69|\u5f85\u6d3e\u5f69/.test(text)) {
      return { label: TEXT.pending, kind: "pending" };
    }
    if (/Half Won|Won|\u8d0f|\u5df2\u4e2d|\u4e2d\u734e/.test(text) && !/Lost|\u672a\u4e2d/.test(text)) {
      return { label: TEXT.win, kind: "win" };
    }
    if (/Half Lost|Lost|\u8f38|\u672a\u4e2d/.test(text)) {
      return { label: TEXT.lose, kind: "lose" };
    }
    if (/Void|Cancelled|\u53d6\u6d88|\u9000\u56de|\u9000\u6b3e/.test(text)) {
      return { label: TEXT.voided, kind: "void" };
    }
    return { label: TEXT.pending, kind: "pending" };
  }

  function parseDate(text) {
    const match = text.match(/20\d{2}[./-]\d{1,2}[./-]\d{1,2}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?|\d{1,2}[./-]\d{1,2}[./-]20\d{2}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?/);
    return match ? match[0].replace(/\./g, "/").replace(/-/g, "/") : "";
  }

  function parseField(text, labels) {
    for (const label of labels) {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const pattern = new RegExp(`${escaped}\\s*[:：]?\\s*([^\\n｜|]{1,42})`, "i");
      const match = text.match(pattern);
      if (match) return cleanValue(match[1]);
    }
    return "";
  }

  function parsePlayFallback(text) {
    const known = [
      "\u4e0d\u8b93\u5206",
      "\u8b93\u5206",
      "\u5927\u5c0f",
      "\u7368\u8d0f",
      "\u55ae\u96d9",
      "\u4e32\u95dc",
      "\u6b63\u78ba\u6bd4\u5206",
    ];
    return known.find((word) => text.includes(word)) || "";
  }

  function parseOptionFallback(text) {
    const arrow = text.match(/(?:->|→)\s*([^\n｜|]{1,42})/);
    if (arrow) return cleanValue(arrow[1]);

    const teamMatch = text.match(/([^\s｜|]{1,18})\s*@\s*([^\s｜|]{1,18})/);
    if (teamMatch) return cleanValue(teamMatch[1]);

    return "";
  }

  function cleanValue(value) {
    return normalizeText(value)
      .replace(/^\s*[:：-]\s*/, "")
      .replace(/\s*(賠率|Odds|金額|Stake|狀態|Status).*$/i, "")
      .slice(0, 42)
      .trim();
  }

  function normalizeText(value) {
    return String(value || "").replace(/\r/g, "\n").replace(/[ \t]+/g, " ").replace(/\n{2,}/g, "\n").trim();
  }

  function isVisible(element) {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "\"": "&quot;",
      "'": "&#039;",
    }[char]));
  }

  function ensureStyles() {
    if (document.getElementById("slb-bet-summary-style")) return;
    const style = document.createElement("style");
    style.id = "slb-bet-summary-style";
    style.textContent = `
      .slb-bet-card {
        position: relative !important;
      }
      .slb-bet-card.${COLLAPSED_CLASS} > :not(.${SUMMARY_CLASS}) {
        display: none !important;
      }
      .${SUMMARY_CLASS} {
        box-sizing: border-box;
        display: grid;
        grid-template-columns: auto minmax(0, 1fr) auto;
        align-items: center;
        gap: 8px;
        width: 100%;
        min-height: 36px;
        margin: 0 0 8px;
        padding: 8px 10px;
        border: 1px solid #d7dce3;
        border-radius: 4px;
        background: #ffffff;
        color: #1f2933;
        cursor: pointer;
        font: 14px/1.35 Arial, "Noto Sans TC", sans-serif;
        text-align: left;
      }
      .${SUMMARY_CLASS}:hover {
        border-color: #9aa4b2;
        background: #f8fafc;
      }
      .slb-result {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 32px;
        height: 22px;
        padding: 0 6px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 700;
      }
      .slb-result-win {
        background: #e5f6eb;
        color: #0f7a3a;
      }
      .slb-result-lose {
        background: #fde8e8;
        color: #b42318;
      }
      .slb-result-pending,
      .slb-result-void {
        background: #edf1f5;
        color: #475467;
      }
      .slb-summary-text {
        min-width: 0;
        overflow-wrap: anywhere;
      }
      .slb-summary-toggle {
        color: #667085;
        font-size: 12px;
      }
    `;
    document.documentElement.appendChild(style);
  }
})();
